# Technical Debts

* Ansible playbook for OS X
* Replace sphinx with tsearch
* Add signup activation
* Well covered specs
* Replace OpenID with Oauth(twitter/facebook)
