Fabricator :result do
  solution
  test(fabricator: :problem_test)
  matched false
  time 1.0
  memory 120
  hidden true
  execution 0
end
