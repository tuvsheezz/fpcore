export PATH="$HOME/.rbenv/bin:$PATH"
eval "$(rbenv init -)"
